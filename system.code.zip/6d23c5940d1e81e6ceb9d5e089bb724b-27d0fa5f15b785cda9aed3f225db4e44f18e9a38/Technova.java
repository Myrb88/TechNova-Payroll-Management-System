package lab05;
class employee {
    public String Name;
    public int ID;
    public double BasicSalary;

    employee(String name, int ID, double BasicSalary){
        this.Name = name;
        this.ID = ID;
        this.BasicSalary = BasicSalary;
    }
    public void calculateSalary(){
        System.out.println("The salary of the parent class is "+ this.BasicSalary);
    }
}

class simpleEmp extends employee {
    simpleEmp(String Name, int ID, double BasicSalary){
        super(Name,ID,BasicSalary);
        System.out.println("Simple employee object created.");
    }
    public void calculateSalary(){
        System.out.println("Simple Employee Salary: "+ this.BasicSalary);
    }
}

class Developer extends employee {
    Developer(String Name, int ID, double BasicSalary){
        super(Name,ID,BasicSalary);
        System.out.println("Developer employee object created.");
    }
    public int overtime;
    public void assignOvertime(int overtime){
        this.overtime = overtime;
    }
    public void calculateSalary(){
        System.out.println("Developer Salary: " + (this.BasicSalary + this.overtime*500) );
    }
}

class Manager extends employee {
    Manager(String Name, int ID, double BasicSalary){
        super(Name,ID,BasicSalary);
        System.out.println("Manager employee object created.");
    }
    public double bonus = 4000;
    {
        System.out.println("Manager Salary: " + (this.BasicSalary + this.bonus));
    }
}

public class Technova {
    public static void main(String[] args) {
        System.out.println("TechNova Payroll Management System");
        employee e1 = new employee("Merab",01, 25000);
        simpleEmp simp = new simpleEmp("Hassan", 02, 25000);
        Developer dev1 = new Developer("Hamza", 03, 25000);
        dev1.assignOvertime(15);
        dev1.calculateSalary();
        Manager m1 = new Manager("Hussain", 04, 25000);
        simp.calculateSalary();
        e1.calculateSalary();
    }

}
